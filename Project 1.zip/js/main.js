// bx slider
$(document).ready(function () {
  $(".slider-area").bxSlider();
  $('#main-menu').meanmenu({
    meanMenuContainer: '#mobile-menu',
    meanScreenWidth: 991,
  });
});

